
Mask Wearing - v4 raw
==============================

This dataset was exported via roboflow.ai on September 19, 2020 at 11:48 AM GMT

It includes 149 images.
People are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


